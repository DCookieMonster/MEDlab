<?php
 phpinfo();
?>