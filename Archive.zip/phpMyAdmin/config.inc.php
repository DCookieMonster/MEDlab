<?php
$i=0;
$i++;
$cfg['Servers'][$i]['socket']        = '/tmp/mysql.sock';
$cfg['Servers'][$i]['user']          = 'root';
$cfg['Servers'][$i]['password']      = '9670';
$cfg['Servers'][$i]['auth_type']     = 'config';
$cfg['AllowUserDropDatabase']        = 'true';
?>