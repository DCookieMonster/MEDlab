<?php 
$sph_messages =  Array (
	"Categories" => "Kategorier",
	"CATEGORIES" => "KATEGORIER",
	"Untitled" => "Ingen titel",
	"Powered by" => "Kraft fr�n",
	"Previous" => "F�reg�ende",
	"Next" => "N�sta",
	"Result page" => "Resultat sidor",
	"Only in category" => "Bara i kategori",
	"Search" => "S�k",
	"All sites" => "Alla sajter",
	"Web pages" => "Webbsidor",
	"noMatch" => "S�kningen \"%query\" gav inga resultat",
	"ignoredWords" => "F�ljande ord utsl�ts (f�r kort eller f�r vanlig): %ignored_words",
	"resultsFor" => "Resultat f�r:",
	"Results" => "Visad resultat %from - %to av %all %matchword (%secs sekunder)", //
	"match" => "matchad",     //
	"matches" => "matchade", //
	"andSearch" => "AND s�k",         
	"orSearch" => "OR s�k",    
	"phraseSearch" => "Fras-s�kning",
	"show" => "Visa ",
	"resultsPerPage" => "resultat per sida",
	"DidYouMean" => "Did you mean"
);
?>