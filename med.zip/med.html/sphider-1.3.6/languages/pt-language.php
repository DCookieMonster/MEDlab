<?php 
$sph_messages =  Array (
	"Categories" => "Categorias",
	"CATEGORIES" => "CATEGORIAS",
	"Untitled" => "Sem t�tulo",
	"Powered by" => "Powered by",
	"Previous" => "Anterior",
	"Next" => "Pr�xima",
	"Result page" => "P�gina",
	"Only in category" => "Somente esta categor�a",
	"Search" => "Pesquisar",
	"All sites" => "Todos os sites",
	"Web pages" => "P�ginas Web",
	"noMatch" => "A pesquisa \"%query\" n�o retornou qualquer ocorr�ncia",
	"ignoredWords" => "Palavras comuns omitidas: %ignored_words",
	"resultsFor" => "Resultados para:",
	"Results" => "Mostrando %from - %to of %all %matchword (%secs segundos)", //
	"match" => "resultado",     //
	"matches" => "resultados", //
	"andSearch" => "AND Search",         
	"orSearch" => "OR Search",    
	"phraseSearch" => "Phrase Search",
	"show" => "Show ",
	"resultsPerPage" => "results per page",
	"DidYouMean" => "Did you mean"
);
?>