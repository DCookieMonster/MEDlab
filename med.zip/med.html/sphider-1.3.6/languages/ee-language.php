<?php 
$sph_messages =  Array (
	"Categories" => "Kataloog",
	"CATEGORIES" => "KATALOOG",
	"Untitled" => "Pealkirjata",
	"Powered by" => "Powered by",
	"Previous" => "<",
	"Next" => ">",
	"Result page" => "Lehek�lg",
	"Only in category" => "Ainult kategooriast",
	"Search" => "Otsi",
	"All sites" => "K�ik lehed",
	"Web pages" => "Veebilehek�ljed",
	"noMatch" => "P�ringule \"%query\" ei vastanud �kski dokument",
	"resultsFor" => "Otsing:",
	"ignoredWords" => "J�rgnevaid s�nu ignoreeriti (liiga l�hikesed v�i �ldised): %ignored_words",
	"Results" => "%matchword %from - %to %all-st (%secs sekundit).", //
	"match" => "Tulemus",      //Pattern:  Results x-y of z match(es). Change according to the pattern
	"matches" => "Tulemused",   // 
	"seconds" => "sekundit",
	"andSearch" => "JA otsing",         
	"orSearch" => "V�I otsing",    
	"phraseSearch" => "Fraasiotsing",
	"show" => "N�ita ",
	"resultsPerPage" => "vastet",
	"DidYouMean" => "Did you mean"
);
?>