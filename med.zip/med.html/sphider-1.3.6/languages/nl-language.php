<?php 
$sph_messages =  Array (
	"Categories" => "Categorie&euml;n",
	"CATEGORIES" => "CATEGORIEEN",
	"Untitled" => "Leeg Document",
	"Powered by" => "Powered by",
	"Previous" => "Vorige",
	"Next" => "Volgende",
	"Result page" => "Resultaten pagina",
	"Only in category" => "Alleen in categorie",
	"Search" => "Zoek",
	"All sites" => "Alle websites",
	"Web pages" => "Web pagina's",
	"noMatch" => "Geen resultaten gevonden.",
	"ignoredWords" => "De volgende woorden zijn overgeslagen (te kort of te algemeen): %ignored_words",
	"resultsFor" => "Resultaten voor:",
	"Results" => "Toon Resultaten %from - %to van %all %matchword (%secs seconden)", //
	"match" => "pagina",     //
	"matches" => "pagina's", //
	"andSearch" => "AND Search",         
	"orSearch" => "OR Search",    
	"phraseSearch" => "Phrase Search",
	"show" => "Show ",
	"resultsPerPage" => "results per page",
	"DidYouMean" => "Did you mean"

);
?>


